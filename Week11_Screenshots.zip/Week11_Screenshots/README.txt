WEEK 11 - SOC THREAT DETECTION, ALERT CORRELATION & INCIDENT RESPONSE
Screenshots folder | Incident DG-SOC-001 | Prepared by: Mah Noor | 5 Nov 2026

LAB
- Windows host (PowerShell, test machine): 192.168.56.1
- soc-snort (Ubuntu 24.04, Snort + Wazuh agent "snort-agent"): 192.168.56.102
- wazuh-server (Wazuh 4.14.9): 192.168.56.103
- Linux logs are in UTC. Pakistan time = UTC+5.
- Wazuh clock is about 22 seconds behind the Linux logs (VM resumed).

FOLDERS
01_Lab_Setup           VM IP addresses.
02_Snort_Monitoring    Ping (SID 1:1000001) and nmap scan (SNMP SIDs 1:1418, 1:1420, 1:1421).
03_SSH_Investigation   Failed SSH logins, auth.log evidence, successful login at 09:10:59 UTC.
04_Wazuh_Monitoring    Agent status, rules 5710, 5760, level-12 rule 40112, MITRE, searches with no result.
05_Week10_Reference    FIM file added/deleted alert from Week 10 (28 Oct 2026).
06_Troubleshooting     Typo fix, proxy error, Wazuh services restart (not needed in the report).

KEY FACTS
- Source IP: 192.168.56.1 | Accounts: wronguser (invalid), snortadmin (valid)
- 8 failed passwords in auth.log, then Accepted password at 09:10:59 UTC
- Wazuh rules: 5710, 5760, 40112 (level 12) | Snort SIDs: 1:1000001, 1:1418, 1:1420, 1:1421

NOTES
- 04/11 and 04/12 show "no results" on purpose (no new rule 5715 or file change in this run).
- Older entries dated 28 Oct 2026 in auth.log are earlier tests, not part of this incident.
